from odoo import fields, models


class ProductTemplate(models.Model):
    _inherit = "product.template"

    cmr_es_flete = fields.Boolean(
        string="Flete en la cotización CMR",
        help="Las líneas con este producto no se muestran dentro de las secciones del PDF de la "
        "cotización: se suman en el renglón FLETE de los totales, como en el formato FT-CTZ-01.",
    )
