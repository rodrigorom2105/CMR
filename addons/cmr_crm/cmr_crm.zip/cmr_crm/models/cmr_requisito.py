from odoo import api, fields, models
from odoo.exceptions import ValidationError


def orden_etapa(stage):
    """Posición de una etapa en el pipeline (mismo orden que el kanban)."""
    return (stage.sequence, stage.id)


class CmrRequisitoEtapa(models.Model):
    _name = "cmr.requisito.etapa"
    _description = "Requisito para avanzar de etapa (CMR)"
    _order = "etapa_sequence, sequence, id"

    name = fields.Char(string="Requisito", compute="_compute_name", store=True)
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    etapa_id = fields.Many2one(
        "crm.stage",
        string="Exigible desde la etapa",
        required=True,
        ondelete="cascade",
        help="Se exige al entrar a esta etapa y a cualquier etapa posterior del pipeline.",
    )
    etapa_sequence = fields.Integer(related="etapa_id.sequence", store=True, string="Orden de etapa")
    tipo_cotizacion_ids = fields.Many2many(
        "cmr.tipo.cotizacion",
        string="Tipos de cotización",
        help="Vacío = aplica a todas las oportunidades, incluso sin tipo de cotización.",
    )
    tipo_requisito = fields.Selection(
        [("documento", "Documento"), ("campo", "Dato de la ficha")],
        string="Tipo de requisito",
        required=True,
        default="documento",
    )
    tipo_documento_id = fields.Many2one("cmr.tipo.documento", string="Documento", ondelete="cascade")
    nivel = fields.Selection(
        [("recibido", "Recibido (aunque su revisión esté pendiente)"), ("revisado", "Revisado")],
        string="Estado mínimo",
        default="recibido",
    )
    acepta_na = fields.Boolean(
        string="Se cumple con «No aplica»",
        default=True,
        help="Si está marcado, el requisito se da por cumplido cuando el documento "
        "se marca como No aplica en la oportunidad.",
    )
    campo_id = fields.Many2one(
        "ir.model.fields",
        string="Dato",
        ondelete="cascade",
        domain="[('model', '=', 'crm.lead'), ('store', '=', True), "
        "('ttype', 'not in', ('one2many', 'many2many', 'binary', 'html'))]",
    )

    _check_destino = models.Constraint(
        "CHECK((tipo_requisito = 'documento' AND tipo_documento_id IS NOT NULL) "
        "OR (tipo_requisito = 'campo' AND campo_id IS NOT NULL))",
        "Indica el documento o el dato que exige el requisito.",
    )

    @api.depends("tipo_requisito", "tipo_documento_id.name", "nivel", "campo_id.field_description")
    def _compute_name(self):
        for req in self:
            if req.tipo_requisito == "documento" and req.tipo_documento_id:
                nivel = "revisado" if req.nivel == "revisado" else "recibido"
                req.name = f"{req.tipo_documento_id.name} ({nivel})"
            elif req.tipo_requisito == "campo" and req.campo_id:
                req.name = req.campo_id.field_description
            else:
                req.name = False

    @api.constrains("campo_id")
    def _check_campo_id(self):
        for req in self:
            if req.campo_id and req.campo_id.model != "crm.lead":
                raise ValidationError("El dato debe ser un campo de la oportunidad.")

    # ------------------------------------------------------------------
    # Evaluación
    # ------------------------------------------------------------------
    def _aplica_a(self, lead):
        self.ensure_one()
        if not self.tipo_cotizacion_ids:
            return True
        return lead.cmr_tipo_cotizacion_id in self.tipo_cotizacion_ids

    def _pendiente(self, lead):
        """Devuelve el texto del pendiente, o False si el requisito se cumple."""
        self.ensure_one()
        if self.tipo_requisito == "documento":
            doc = lead.cmr_documento_ids.filtered(lambda d: d.tipo_documento_id == self.tipo_documento_id)[:1]
            nombre = self.tipo_documento_id.name
            estado = doc.estado if doc else "faltante"
            if estado == "revisado":
                return False
            if estado == "na":
                return False if self.acepta_na else f"{nombre}: marcado No aplica, pero es obligatorio"
            if estado == "recibido":
                return False if self.nivel == "recibido" else f"{nombre}: recibido, revisión pendiente"
            return f"{nombre}: faltante"
        # Dato de la ficha
        campo = self.campo_id
        if not campo or campo.name not in lead._fields:
            return False
        valor = lead[campo.name]
        return False if valor else f"{campo.field_description}: sin capturar"
