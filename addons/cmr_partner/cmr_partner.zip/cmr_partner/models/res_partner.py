from odoo import api, fields, models

from .sat_catalogs import FORMA_PAGO, METODO_PAGO, REGIMEN_FISCAL, USO_CFDI

ADDRESS_FIELDS = ('cmr_calle', 'cmr_num_ext', 'cmr_num_int', 'cmr_colonia')
GENERIC_RFCS = ('XAXX010101000', 'XEXX010101000')


class ResPartner(models.Model):
    _inherit = 'res.partner'

    # --- Datos fiscales SAT -------------------------------------------------
    # Las etiquetas coinciden con los encabezados del Excel de Factura Total.
    cmr_regimen_fiscal = fields.Selection(REGIMEN_FISCAL, string='Régimen fiscal')
    cmr_uso_cfdi = fields.Selection(USO_CFDI, string='Uso de CFDI')
    cmr_forma_pago = fields.Selection(FORMA_PAGO, string='Forma de pago')
    cmr_metodo_pago = fields.Selection(METODO_PAGO, string='Método de pago')

    # --- Domicilio fiscal desglosado ----------------------------------------
    # Al guardarlos se recompone la dirección nativa: Calle = "calle núm. Int. x",
    # Calle 2 = "Col. colonia". El municipio se guarda en el campo nativo Ciudad.
    cmr_calle = fields.Char(string='Dirección', help='Nombre de la calle, sin número.')
    cmr_num_ext = fields.Char(string='Num. Ext.')
    cmr_num_int = fields.Char(string='Num. Int.')
    cmr_colonia = fields.Char(string='Colonia')

    # ------------------------------------------------------------------------
    @api.model
    def _cmr_clean_vals(self, vals):
        """Normaliza RFC, correos y números que llegan como número desde Excel."""
        if vals.get('vat'):
            vals['vat'] = vals['vat'].replace(' ', '').replace('-', '').upper()
        if vals.get('email'):
            emails = vals['email'].replace(';', ',').split(',')
            vals['email'] = ', '.join(e.strip() for e in emails if e.strip())
        for fname in ADDRESS_FIELDS + ('zip',):
            if isinstance(vals.get(fname), (int, float)) and not isinstance(vals.get(fname), bool):
                vals[fname] = str(int(vals[fname]))
        return vals

    def _cmr_compose_address(self):
        for partner in self:
            street = ' '.join(filter(None, [partner.cmr_calle, partner.cmr_num_ext]))
            if partner.cmr_num_int:
                street = f'{street} Int. {partner.cmr_num_int}'.strip()
            values = {'street': street or False}
            if partner.cmr_colonia:
                values['street2'] = f'Col. {partner.cmr_colonia}'
            super(ResPartner, partner).write(values)

    def _cmr_fix_mx_zip(self):
        """Excel elimina los ceros a la izquierda: 6600 -> 06600 (solo México)."""
        for partner in self:
            zip_code = (partner.zip or '').strip()
            if partner.country_id.code == 'MX' and zip_code.isdigit() and len(zip_code) < 5:
                super(ResPartner, partner).write({'zip': zip_code.zfill(5)})

    @api.model
    def _run_vat_checks(self, country, vat, partner_name='', validation='error'):
        """Los RFC genéricos del SAT (XEXX010101000 extranjero, XAXX010101000 público
        en general) son válidos para cualquier país: no se validan contra el formato
        fiscal del país del contacto (p. ej. Costa Rica o Guatemala)."""
        if vat and vat.replace(' ', '').upper() in GENERIC_RFCS:
            return vat.replace(' ', '').upper(), 'MX'
        return super()._run_vat_checks(country, vat, partner_name=partner_name, validation=validation)

    @api.depends('country_id')
    def _compute_is_company(self):
        """En Odoo 20 un contacto es empresa si tiene RFC. Para México se afina con
        la regla del SAT: RFC de 13 caracteres = persona física (no es empresa),
        igual que hace l10n_es con los autónomos. RFC de 12 = persona moral.
        XAXX010101000 (público en general) tampoco es empresa."""
        super()._compute_is_company()
        for partner in self:
            vat = (partner.vat or '').upper()
            if partner.commercial_partner_id != partner or partner.country_code not in ('MX', False):
                continue
            if vat == 'XAXX010101000' or (len(vat) == 13 and vat not in GENERIC_RFCS):
                partner.is_company = False

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            self._cmr_clean_vals(vals)
        partners = super().create(vals_list)
        for partner, vals in zip(partners, vals_list):
            if any(f in vals for f in ADDRESS_FIELDS) and 'street' not in vals:
                partner._cmr_compose_address()
        partners._cmr_fix_mx_zip()
        return partners

    def write(self, vals):
        self._cmr_clean_vals(vals)
        res = super().write(vals)
        if any(f in vals for f in ADDRESS_FIELDS) and 'street' not in vals:
            self._cmr_compose_address()
        if 'zip' in vals or 'country_id' in vals:
            self._cmr_fix_mx_zip()
        return res
