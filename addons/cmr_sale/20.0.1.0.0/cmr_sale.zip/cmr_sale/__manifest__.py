{
    "name": "CMR - Ventas",
    "summary": "Cotizaciones CMR: número de cotización proyecto-opción-año (283- 12-26)",
    "version": "20.0.1.0.0",
    "category": "Sales/Sales",
    "author": "Cili",
    "license": "LGPL-3",
    "depends": ["sale_crm", "sale_management", "cmr_crm"],
    "data": [
        "data/ir_sequence_data.xml",
        "views/res_config_settings_views.xml",
        "views/crm_lead_views.xml",
        "views/sale_order_views.xml",
    ],
    "installable": True,
    "application": False,
}
