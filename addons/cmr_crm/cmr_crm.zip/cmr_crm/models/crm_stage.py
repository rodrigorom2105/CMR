from odoo import fields, models


class CrmStage(models.Model):
    _inherit = "crm.stage"

    cmr_requisito_ids = fields.One2many(
        "cmr.requisito.etapa",
        "etapa_id",
        string="Requisitos para entrar",
        help="Documentos y datos que debe tener una oportunidad para entrar a esta etapa "
        "o a cualquier etapa posterior.",
    )
    cmr_plan_id = fields.Many2one(
        "mail.activity.plan",
        string="Plan de actividades al entrar",
        domain="[('res_model', '=', 'crm.lead')]",
        help="Al entrar una oportunidad a esta etapa se programan las actividades del plan "
        "(responsable y vencimiento según la plantilla). Las actividades «a definir» "
        "se asignan al vendedor de la oportunidad.",
    )
    cmr_congela_ficha = fields.Boolean(
        string="Congela la ficha ESP-TEC",
        help="Desde esta etapa y en todas las posteriores, la ficha ESP-TEC de la oportunidad queda "
        "en solo lectura, salvo los documentos y planos y los datos que captura Ingeniería. "
        "Para corregirla hay que regresar la oportunidad a una etapa anterior; cada regreso "
        "queda registrado.",
    )
