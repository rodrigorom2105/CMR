{
    "name": "CMR - Ventas",
    "summary": "Cotizaciones CMR: número proyecto-opción-año (283- 12-26) y formato PDF FT-CTZ-01",
    "version": "20.0.1.1.0",
    "category": "Sales/Sales",
    "author": "Cili",
    "license": "LGPL-3",
    "depends": ["sale_crm", "sale_management", "cmr_crm"],
    "data": [
        "security/ir.access.csv",
        "data/ir_sequence_data.xml",
        "report/cmr_cotizacion_report.xml",
        "views/res_config_settings_views.xml",
        "views/crm_lead_views.xml",
        "views/sale_order_views.xml",
        "views/product_views.xml",
    ],
    "assets": {
        "web.report_assets_common": [
            "cmr_sale/static/src/css/cmr_cotizacion.css",
        ],
    },
    "installable": True,
    "application": False,
}
