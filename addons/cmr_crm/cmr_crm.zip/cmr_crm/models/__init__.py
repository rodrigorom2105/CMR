from . import cmr_catalogos
from . import cmr_requisito
from . import crm_stage
from . import crm_lead_documento
from . import crm_lead
