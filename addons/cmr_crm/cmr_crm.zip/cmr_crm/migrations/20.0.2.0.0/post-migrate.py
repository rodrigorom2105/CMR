"""Migración 20.0.1.0.0 → 20.0.2.0.0

- Las 4 casillas de planos pasan a líneas de documento con estado.
- cmr_tipo_proyecto (nuevo / adaptación) pasa a Tipo de cotización.
- El gate por etapa (cmr_requiere_gate) se sustituye por requisitos configurables.
Las columnas viejas se conservan en la base de datos (sin uso) como respaldo.
"""
import logging

from odoo import SUPERUSER_ID, api

_logger = logging.getLogger(__name__)

# columna anterior -> xmlid del documento
PLANOS = {
    "cmr_plantas_arq": "cmr_crm.doc_planos_plantas",
    "cmr_cortes_fachadas": "cmr_crm.doc_cortes_fachadas",
    "cmr_plano_estructural": "cmr_crm.doc_estructural",
    "cmr_plano_azotea": "cmr_crm.doc_azotea",
}
TIPOS = {
    "nuevo": "cmr_crm.tipo_cot_molde_completo",
    "adaptacion": "cmr_crm.tipo_cot_adaptacion",
}


def _columnas(cr, tabla):
    cr.execute("SELECT column_name FROM information_schema.columns WHERE table_name = %s", (tabla,))
    return {fila[0] for fila in cr.fetchall()}


def migrate(cr, version):
    if not version:
        return
    env = api.Environment(cr, SUPERUSER_ID, {"active_test": False, "cmr_skip_tag_sync": True, "tracking_disable": True})
    columnas = _columnas(cr, "crm_lead")

    # Fecha de la ficha: la de creación de la oportunidad, no la de la migración
    cr.execute("UPDATE crm_lead SET cmr_esptec_fecha = create_date::date WHERE create_date IS NOT NULL")

    # Tipo de proyecto -> Tipo de cotización
    if "cmr_tipo_proyecto" in columnas:
        for valor, xmlid in TIPOS.items():
            tipo = env.ref(xmlid, raise_if_not_found=False)
            if tipo:
                cr.execute(
                    "UPDATE crm_lead SET cmr_tipo_cotizacion_id = %s "
                    "WHERE cmr_tipo_proyecto = %s AND cmr_tipo_cotizacion_id IS NULL",
                    (tipo.id, valor),
                )
                _logger.info("cmr_crm: %s oportunidades con tipo '%s' -> %s", cr.rowcount, valor, tipo.name)

    # Casillas de planos -> documentos
    planos_presentes = [col for col in PLANOS if col in columnas]
    marcados = {}
    if planos_presentes:
        cr.execute("SELECT id, %s FROM crm_lead" % ", ".join(planos_presentes))  # noqa: S608 - columnas fijas
        for fila in cr.fetchall():
            marcados[fila[0]] = {col for col, valor in zip(planos_presentes, fila[1:]) if valor}
    doc_por_columna = {col: env.ref(xmlid, raise_if_not_found=False) for col, xmlid in PLANOS.items()}
    recibido_en = {doc.id: col for col, doc in doc_por_columna.items() if doc}

    tipos_defecto = env["cmr.tipo.documento"].search([("crear_por_defecto", "=", True)])
    leads = env["crm.lead"].search([])
    valores = []
    for lead in leads:
        existentes = lead.cmr_documento_ids.tipo_documento_id
        for tipo in tipos_defecto - existentes:
            columna = recibido_en.get(tipo.id)
            estado = "recibido" if columna and columna in marcados.get(lead.id, set()) else "faltante"
            valores.append({
                "lead_id": lead.id,
                "tipo_documento_id": tipo.id,
                "sequence": tipo.sequence,
                "estado": estado,
                "notas": "Migrado de la versión anterior" if estado == "recibido" else False,
            })
    if valores:
        env["crm.lead.documento"].create(valores)
    _logger.info("cmr_crm: %s líneas de documento creadas en %s oportunidades", len(valores), len(leads))

    # Etiqueta: ahora cubre documentos y datos faltantes para la siguiente etapa
    tag = env.ref("cmr_crm.tag_falta_documentacion", raise_if_not_found=False)
    if tag and tag.name == "Falta documentación":
        tag.name = "Pendientes para avanzar"
    oportunidades = leads.filtered(lambda l: l.type == "opportunity" and l.active)
    oportunidades.with_context(cmr_skip_tag_sync=False)._cmr_sync_tag_documentacion()
