from odoo import api, fields, models

TIPOS_HITO = [
    ("anticipo", "Anticipo"),
    ("contra_bl", "Contra BL"),
    ("arribo_puerto", "Contra arribo a puerto"),
    ("entrega_fabrica", "Contra entrega en fábrica"),
    ("entrega_obra", "Contra entrega en obra"),
    ("validacion", "Contra validación"),
    ("finiquito", "Finiquito"),
    ("contado", "Al contado"),
    ("leasing", "Leasing"),
    ("otro", "Otro"),
]


class CmrSaleHito(models.Model):
    """Hito de pago de una cotización (forma de pago del formato FT-CTZ-01)."""

    _name = "cmr.sale.hito"
    _description = "Hito de pago de la cotización (CMR)"
    _order = "sequence, id"

    order_id = fields.Many2one("sale.order", string="Cotización", required=True, ondelete="cascade", index=True)
    sequence = fields.Integer(default=10)
    tipo = fields.Selection(TIPOS_HITO, string="Hito", required=True, default="anticipo")
    detalle = fields.Char(string="Detalle", help="Texto adicional, por ejemplo «por planta» o «por nivel».")
    porcentaje = fields.Float(string="%", digits=(16, 2))
    alternativa = fields.Boolean(
        string="Alternativa",
        help="Forma de pago alternativa, como «100 % leasing» o «al contado». "
        "No se suma con los demás hitos.",
    )
    currency_id = fields.Many2one(related="order_id.currency_id")
    monto = fields.Monetary(string="Monto", compute="_compute_monto", currency_field="currency_id")

    @api.depends("porcentaje", "order_id.amount_total")
    def _compute_monto(self):
        for hito in self:
            hito.monto = hito.order_id.amount_total * hito.porcentaje / 100.0

    def _cmr_texto(self):
        """Texto del hito como lo escribe CMR: «60% ANTICIPO», «100% LEASING»."""
        self.ensure_one()
        etiqueta = dict(self._fields["tipo"]._description_selection(self.env)).get(self.tipo, "")
        partes = []
        if self.porcentaje:
            partes.append(f"{self.porcentaje:g}%")
        if self.tipo != "otro" or not self.detalle:
            partes.append(etiqueta)
        if self.detalle:
            partes.append(self.detalle)
        return " ".join(partes).upper()


class CmrSaleEntrega(models.Model):
    """Plazo de entrega de una cotización (tiempo de entrega del formato FT-CTZ-01)."""

    _name = "cmr.sale.entrega"
    _description = "Plazo de entrega de la cotización (CMR)"
    _order = "sequence, id"

    order_id = fields.Many2one("sale.order", string="Cotización", required=True, ondelete="cascade", index=True)
    sequence = fields.Integer(default=10)
    plazo = fields.Char(string="Plazo", required=True, help="Por ejemplo: 90 a 120 días, 105 días.")
    descripcion = fields.Char(
        string="Descripción o condición",
        help="Por ejemplo: entrega de 1 dúplex; una vez recibido el anticipo y firmado el Shell Plan.",
    )


class CmrSaleMemoria(models.Model):
    """Imagen de la memoria gráfica de una cotización."""

    _name = "cmr.sale.memoria"
    _description = "Imagen de memoria gráfica de la cotización (CMR)"
    _order = "sequence, id"

    order_id = fields.Many2one("sale.order", string="Cotización", required=True, ondelete="cascade", index=True)
    sequence = fields.Integer(default=10)
    imagen = fields.Image(string="Imagen", required=True, max_width=1600, max_height=1600)
    leyenda = fields.Char(string="Leyenda", help="Por ejemplo: equipo base, área cotizada, escalera.")
