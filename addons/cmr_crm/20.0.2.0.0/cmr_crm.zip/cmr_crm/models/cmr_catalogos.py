from odoo import fields, models


class CmrTipoCotizacion(models.Model):
    _name = "cmr.tipo.cotizacion"
    _description = "Tipo de cotización CMR"
    _order = "sequence, id"

    name = fields.Char(string="Tipo de cotización", required=True, translate=True)
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    descripcion = fields.Text(string="Descripción")
    # Secciones del ESP-TEC que aplican a este tipo. Las secciones de datos
    # generales, datos del proyecto, alcance y notas se muestran siempre.
    seccion_planos = fields.Boolean(string="Planos arquitectónicos", default=True)
    seccion_tecnica = fields.Boolean(string="Información técnica y seguridad", default=True)
    seccion_arquitectonica = fields.Boolean(string="Detalles arquitectónicos", default=True)
    seccion_punto_fijo = fields.Boolean(string="Punto fijo y escaleras", default=True)
    seccion_constructiva = fields.Boolean(string="Detalles constructivos", default=True)


class CmrTipoProducto(models.Model):
    _name = "cmr.tipo.producto"
    _description = "Tipo de producto CMR (sistema de molde)"
    _order = "sequence, id"

    name = fields.Char(string="Tipo de producto", required=True)
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)


class CmrTipoDocumento(models.Model):
    _name = "cmr.tipo.documento"
    _description = "Tipo de documento o plano CMR"
    _order = "sequence, id"

    name = fields.Char(string="Documento", required=True)
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    crear_por_defecto = fields.Boolean(
        string="Agregar a oportunidades nuevas",
        default=True,
        help="Si está marcado, cada oportunidad nueva incluye este documento en estado Faltante.",
    )
    descripcion = fields.Text(string="Descripción")
