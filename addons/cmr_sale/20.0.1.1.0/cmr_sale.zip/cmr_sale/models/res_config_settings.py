from odoo import api, fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    cmr_proyecto_siguiente = fields.Integer(
        string="Siguiente número de proyecto",
        help="Número que tomará el próximo proyecto (oportunidad) que se cotice este año. "
        "El 1 de enero vuelve a empezar en 1.",
    )

    @api.model
    def _cmr_rango_actual(self):
        secuencia = self.env.ref("cmr_sale.seq_cmr_proyecto").sudo()
        hoy = fields.Date.context_today(self)
        rango = secuencia.date_range_ids.filtered(lambda r: r.date_from <= hoy <= r.date_to)[:1]
        return rango or secuencia._create_date_range_seq(hoy)

    @api.model
    def get_values(self):
        res = super().get_values()
        res["cmr_proyecto_siguiente"] = self._cmr_rango_actual().number_next_actual
        return res

    def set_values(self):
        super().set_values()
        rango = self._cmr_rango_actual()
        if self.cmr_proyecto_siguiente and self.cmr_proyecto_siguiente != rango.number_next_actual:
            rango.number_next_actual = self.cmr_proyecto_siguiente
