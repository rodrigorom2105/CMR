import logging

from odoo import Command, api, fields, models
from odoo.exceptions import UserError

from .cmr_requisito import orden_etapa

_logger = logging.getLogger(__name__)

# Opciones comunes del ESP-TEC (lista "N/A, SI, NO" del formato)
SI_NO_NA = [("si", "Sí"), ("no", "No"), ("na", "N/A")]

# Código del formato vigente (celda AK1 del ESP-TEC)
FORMATO_ESPTEC = "ET-COT-01-1-24"

# Campos cuyo cambio puede alterar el cumplimiento de requisitos
CAMPOS_REQUISITOS_BASE = {"stage_id", "type", "team_id", "cmr_tipo_cotizacion_id", "cmr_documento_ids", "active"}

# CILI-08 · Campos de la ficha ESP-TEC que se congelan al entrar a una etapa que congela
# (Volumetría Preliminar). Quedan editables: documentos y planos con sus datos generales,
# Nº de cotización, complejidad del molde y m² cotizados, que se capturan después.
CAMPOS_FICHA_CONGELABLE = frozenset("""
    cmr_esptec_formato cmr_esptec_enlace cmr_esptec_fecha cmr_termino_negociacion
    cmr_tipo_cotizacion_id cmr_obra_nombre cmr_obra_ciudad cmr_cant_equipos cmr_cant_adaptaciones
    cmr_cant_viviendas cmr_tipo_producto_id
    cmr_altura_libre cmr_tipo_union cmr_espesor_muro cmr_espesor_losa cmr_enrase_puertas
    cmr_enrase_ventanas cmr_juegos_losa_puntal cmr_juegos_reapuntalamiento cmr_config_equipo
    cmr_alineacion_vertical
    cmr_sistema_seguridad cmr_seguridad_cantidad cmr_mensulas cmr_plataformas cmr_guarda_cuerpo
    cmr_requiere_puntales cmr_seguridad_vaciado cmr_linea_vida cmr_juegos_adic_reapuntalamiento
    cmr_alineacion_horizontal
    cmr_muros_texturados cmr_losa_inclinada cmr_dilataciones_fachada cmr_culatas
    cmr_ventanas_especiales cmr_negativos_carriolas cmr_junta_muros_internos cmr_junta_antepechos
    cmr_perforaciones_muros cmr_negativos_acero_losa cmr_pretiles cmr_base_tinaco
    cmr_perforaciones_losa cmr_torreon cmr_domo cmr_gargolas cmr_vigas_descolgadas
    cmr_vigas_peraltadas cmr_dilatacion_borde_losa cmr_gotero_bordes_losa
    cmr_cotizar_punto_fijo cmr_punto_fijo_alcance cmr_cuarto_maquinas cmr_cotizar_escaleras
    cmr_tipo_escalera cmr_cant_escaleras cmr_losa_cubre_escaleras cmr_escalera_posicion
    cmr_proceso_constructivo
    cmr_forma_construccion cmr_juntas_dilatacion cmr_espesor_junta cmr_desnivel_viviendas
    cmr_altura_desnivel cmr_retroceso_viviendas
    cmr_alcance_cotizacion cmr_caracteristicas cmr_secuencia_vaciados cmr_notas_generales
""".split())

# Contexto para editar una ficha congelada desde código (migraciones, scripts de soporte)
CTX_EDITAR_CONGELADA = "cmr_editar_ficha_congelada"


def _si_no_na(etiqueta, **kw):
    return fields.Selection(SI_NO_NA, string=etiqueta, **kw)


def _cm(etiqueta, **kw):
    return fields.Float(string=etiqueta, digits=(16, 2), **kw)


class CrmLead(models.Model):
    _inherit = "crm.lead"

    # ------------------------------------------------------------------
    # Encabezado (filas 1-4) y datos generales (filas 6-11)
    # Cliente, contacto, cargo, correo, dirección, país, ciudad, teléfono
    # y asesor comercial son los campos nativos de la oportunidad.
    # ------------------------------------------------------------------
    cmr_esptec_formato = fields.Char(string="Formato ESP-TEC", default=FORMATO_ESPTEC, copy=False)
    cmr_esptec_enlace = fields.Char(string="Archivo ESP-TEC", help="Enlace al Excel ESP-TEC vigente (SharePoint).")
    cmr_esptec_fecha = fields.Date(string="Fecha de la ficha", default=fields.Date.context_today, copy=False)
    cmr_num_cotizacion = fields.Char(string="Cotización Nº", copy=False, tracking=True)
    cmr_termino_negociacion = fields.Selection(
        [("ddp", "DDP (Puesto en obra)"), ("exw", "EXWORK (Puesto en planta)")],
        string="Término de negociación",
        tracking=True,
    )

    # ------------------------------------------------------------------
    # Datos del proyecto (filas 13-15)
    # ------------------------------------------------------------------
    cmr_tipo_cotizacion_id = fields.Many2one(
        "cmr.tipo.cotizacion", string="Tipo de cotización", tracking=True, index=True,
    )
    cmr_obra_nombre = fields.Char(string="Nombre de la obra")
    cmr_obra_ciudad = fields.Char(string="Ciudad de la obra")
    cmr_cant_equipos = fields.Integer(string="Cantidad de equipos")
    cmr_cant_adaptaciones = fields.Integer(string="Cantidad de adaptaciones o cambios")
    cmr_cant_viviendas = fields.Integer(string="Viviendas a construir")
    cmr_tipo_producto_id = fields.Many2one("cmr.tipo.producto", string="Tipo de producto")
    cmr_alcance_molde = fields.Selection(
        [("sencillo", "Sencillo"), ("medio", "Medio"), ("complejo", "Complejo"), ("adaptacion", "Adaptación")],
        string="Complejidad del molde",
        help="Dato del prototipo para estimar la carga de Ingeniería (no forma parte del ESP-TEC).",
    )
    cmr_m2_cotizados = fields.Float(string="m² Cotizados", digits=(16, 2))
    cmr_m2_ponderados = fields.Float(
        string="m² Ponderados",
        digits=(16, 2),
        compute="_compute_cmr_m2_ponderados",
        store=True,
        help="m² cotizados × probabilidad. Definición pendiente de confirmar con CMR (CMR-04).",
    )

    # ------------------------------------------------------------------
    # Planos arquitectónicos (filas 17-20): el detalle por plano está en
    # cmr_documento_ids; aquí van los datos generales del juego de planos.
    # ------------------------------------------------------------------
    cmr_documento_ids = fields.One2many(
        "crm.lead.documento", "lead_id", string="Documentos y planos", copy=True,
        default=lambda self: self._cmr_documentos_por_defecto(),
    )
    cmr_planos_fecha_act = fields.Date(string="Fecha de actualización de planos")
    cmr_planos_version = fields.Integer(string="Versión de planos")
    cmr_planos_formato = fields.Selection(
        [("cad", "CAD"), ("pdf", "PDF"), ("ifc", "IFC"), ("rvt", "RVT"), ("bim", "BIM")],
        string="Formato de planos",
    )
    cmr_clave_bim = fields.Char(string="Clave BIM")

    # ------------------------------------------------------------------
    # Información técnica del proyecto, medidas en cm (filas 22-26)
    # ------------------------------------------------------------------
    cmr_altura_libre = _cm("Altura libre (cm)")
    cmr_tipo_union = fields.Selection(
        [("lisa", "Lisa"), ("cornisa", "Cornisa"), ("cuchilla", "Cuchilla")], string="Tipo de unión",
    )
    cmr_espesor_muro = _cm("Espesor de muro (cm)")
    cmr_espesor_losa = _cm("Espesor de losa (cm)")
    cmr_enrase_puertas = _cm("Enrase puertas (cm)")
    cmr_enrase_ventanas = _cm("Enrase ventanas (cm)")
    cmr_juegos_losa_puntal = fields.Integer(string="Juegos de losa puntal")
    cmr_juegos_reapuntalamiento = fields.Integer(string="Juegos de losa puntal o reapuntalamiento")
    cmr_config_equipo = fields.Selection(
        [("210", "210"), ("240", "240"), ("270", "270")], string="Configuración equipo FM estándar (cm)",
    )
    cmr_alto_eql = fields.Float(
        string="Alto EQL (cm)", digits=(16, 2), compute="_compute_cmr_altos", store=True,
        help="Altura libre − configuración del equipo − espesor de losa (fórmula de N26 del ESP-TEC).",
    )
    cmr_alto_cap = fields.Float(
        string="Alto CAP (cm)", digits=(16, 2), compute="_compute_cmr_altos", store=True,
        help="Altura libre − configuración del equipo + espesor de losa (fórmula de Z26 del ESP-TEC).",
    )
    cmr_alineacion_vertical = fields.Selection(
        [("agr", "AGR"), ("agrd", "AGRD"), ("collarin", "Collarín de ciclo"), ("na", "N/A")],
        string="Alineación vertical",
    )

    # Sistema de seguridad (filas 27-30)
    cmr_sistema_seguridad = _si_no_na("Sistema de seguridad")
    cmr_seguridad_cantidad = fields.Selection(
        [
            ("medio_perimetro", "Medio perímetro"),
            ("perimetro", "1 Perímetro"),
            ("perimetro_dpto", "Perímetro + 1 Dpto."),
            ("perimetro_medio", "Perímetro y medio"),
            ("dos_perimetros", "Dos perímetros"),
        ],
        string="Cantidad de sistema de seguridad",
    )
    cmr_mensulas = _si_no_na("Ménsulas")
    cmr_plataformas = _si_no_na("Plataformas")
    cmr_guarda_cuerpo = _si_no_na("Guarda cuerpo")
    cmr_requiere_puntales = _si_no_na("Requiere puntales (1 juego incluido)")
    cmr_seguridad_vaciado = _si_no_na("Sistema de seguridad para vaciado")
    cmr_linea_vida = _si_no_na("Línea de vida tubular")
    cmr_juegos_adic_reapuntalamiento = fields.Integer(string="Juegos adicionales de reapuntalamiento")
    cmr_alineacion_horizontal = fields.Selection(
        [("angulo", "Ángulo de acero"), ("doble_tubo", "Doble tubo"), ("na", "N/A")],
        string="Sistema de alineación horizontal para muros",
    )

    # ------------------------------------------------------------------
    # Detalles arquitectónicos - ubicar en planos (filas 32-38)
    # ------------------------------------------------------------------
    cmr_muros_texturados = fields.Selection(
        [("na", "N/A"), ("si", "Sí"), ("no", "No"), ("ladrillo", "Tipo ladrillo")],
        string="Muros con formaleta texturada",
    )
    cmr_losa_inclinada = _si_no_na("Losa inclinada")
    cmr_dilataciones_fachada = fields.Selection(
        [("na", "N/A"), ("si", "Sí"), ("no", "No"), ("estandar", "Estándar"), ("especial", "Especial")],
        string="Dilataciones en fachadas",
    )
    cmr_culatas = fields.Selection(
        [("na", "N/A"), ("internas", "Internas"), ("perimetrales", "Perimetrales"), ("ambas", "Int. + Perim.")],
        string="Culatas",
    )
    cmr_ventanas_especiales = fields.Selection(
        [("na", "N/A"), ("rebordes", "Rebordes"), ("alfajia_sup", "Alfajía Sup."), ("alfajia_inf", "Alfajía Inf.")],
        string="Ventanas especiales",
    )
    cmr_negativos_carriolas = _si_no_na("Negativos para carriolas")
    cmr_junta_muros_internos = _si_no_na("Junta de control muros internos")
    cmr_junta_antepechos = _si_no_na("Junta de control en antepechos")
    cmr_perforaciones_muros = _si_no_na("Perforaciones en cara de contacto muros")
    cmr_negativos_acero_losa = _si_no_na("Negativos en acero para losa")
    cmr_pretiles = _si_no_na("Pretiles")
    cmr_base_tinaco = _si_no_na("Base de tinaco")
    cmr_perforaciones_losa = _si_no_na("Perforaciones en cara de contacto losa")
    cmr_torreon = _si_no_na("Torreón")
    cmr_domo = _si_no_na("Domo")
    cmr_gargolas = _si_no_na("Gárgolas")
    cmr_vigas_descolgadas = _si_no_na("Vigas descolgadas")
    cmr_vigas_peraltadas = _si_no_na("Vigas peraltadas")
    cmr_dilatacion_borde_losa = fields.Selection(
        [("na", "N/A"), ("1_linea", "1 Línea"), ("2_lineas", "2 Líneas"), ("especial", "Especial")],
        string="Dilatación borde de losa",
    )
    cmr_gotero_bordes_losa = _si_no_na("Dilatación gotero en bordes de losa")

    # ------------------------------------------------------------------
    # Punto fijo - área común (filas 40-43)
    # ------------------------------------------------------------------
    cmr_cotizar_punto_fijo = _si_no_na("Cotizar punto fijo")
    cmr_punto_fijo_alcance = fields.Selection(
        [("completo", "Completo"), ("medio", "Medio")], string="Cantidad de punto fijo",
    )
    cmr_cuarto_maquinas = _si_no_na("Cuarto de máquinas")
    cmr_cotizar_escaleras = _si_no_na("Cotizar escaleras")
    cmr_tipo_escalera = fields.Selection(
        [("1_tramo", "1 Tramo"), ("2_tramos", "2 Tramos"), ("caracol", "En caracol"), ("l", "En «L»")],
        string="Tipo de escalera",
    )
    cmr_cant_escaleras = fields.Integer(string="Cantidad de escaleras")
    cmr_losa_cubre_escaleras = _si_no_na("Losa para cubrir escaleras")
    cmr_escalera_posicion = fields.Selection(
        [("na", "N/A"), ("unica", "Única posición"), ("espejo", "Espejo")], string="Se considera escalera",
    )
    cmr_proceso_constructivo = fields.Selection(
        [("monolitica", "Monolítica"), ("posterior", "Posterior")], string="Proceso constructivo",
    )

    # ------------------------------------------------------------------
    # Detalles constructivos - ubicar en planos (filas 45-47)
    # ------------------------------------------------------------------
    cmr_forma_construccion = fields.Selection(
        [("espejo", "Espejo"), ("pareado", "Pareado"), ("aislado", "Aislado"), ("espejo_pareado", "Espejo + Pareado")],
        string="Forma de construcción",
    )
    cmr_juntas_dilatacion = _si_no_na("Juntas de dilatación entre viviendas")
    cmr_espesor_junta = _cm("Espesor junta de dilatación (cm)")
    cmr_desnivel_viviendas = _si_no_na("Desnivel entre viviendas")
    cmr_altura_desnivel = _cm("Altura de desnivel (cm)")
    cmr_retroceso_viviendas = _si_no_na("Retroceso entre viviendas")

    # ------------------------------------------------------------------
    # Textos (A49, A51, A53, A55)
    # ------------------------------------------------------------------
    cmr_alcance_cotizacion = fields.Text(string="Alcance de la cotización")
    cmr_caracteristicas = fields.Text(string="Características principales del proyecto")
    cmr_secuencia_vaciados = fields.Text(string="Secuencia de vaciados acordada y aprobada por el cliente")
    cmr_notas_generales = fields.Text(string="Notas generales")

    # ------------------------------------------------------------------
    # Visibilidad por tipo de cotización y estado de requisitos
    # ------------------------------------------------------------------
    cmr_ver_planos = fields.Boolean(compute="_compute_cmr_secciones")
    cmr_ver_tecnica = fields.Boolean(compute="_compute_cmr_secciones")
    cmr_ver_arquitectonica = fields.Boolean(compute="_compute_cmr_secciones")
    cmr_ver_punto_fijo = fields.Boolean(compute="_compute_cmr_secciones")
    cmr_ver_constructiva = fields.Boolean(compute="_compute_cmr_secciones")

    cmr_siguiente_etapa_id = fields.Many2one("crm.stage", string="Siguiente etapa", compute="_compute_cmr_pendientes")
    cmr_pendientes = fields.Text(string="Pendiente para avanzar", compute="_compute_cmr_pendientes")
    cmr_pendientes_titulo = fields.Char(compute="_compute_cmr_pendientes")

    # ------------------------------------------------------------------
    # Congelamiento de la ficha (CILI-08)
    # ------------------------------------------------------------------
    cmr_ficha_congelada = fields.Boolean(
        string="Ficha congelada", compute="_compute_cmr_ficha_congelada",
        help="La etapa actual (o una anterior del pipeline) congela la ficha ESP-TEC.",
    )
    cmr_congelada_el = fields.Datetime(string="Ficha congelada el", readonly=True, copy=False)
    cmr_congelada_por_id = fields.Many2one("res.users", string="Congelada por", readonly=True, copy=False)
    cmr_regresos_revision = fields.Integer(
        string="Regresos a revisión", readonly=True, copy=False, default=0,
        help="Veces que la oportunidad salió de una etapa congelada hacia una etapa anterior "
        "para corregir la especificación.",
    )

    # ------------------------------------------------------------------
    # Cálculos
    # ------------------------------------------------------------------
    @api.depends("cmr_m2_cotizados", "probability")
    def _compute_cmr_m2_ponderados(self):
        for lead in self:
            lead.cmr_m2_ponderados = lead.cmr_m2_cotizados * (lead.probability or 0.0) / 100.0

    @api.depends("cmr_altura_libre", "cmr_config_equipo", "cmr_espesor_losa")
    def _compute_cmr_altos(self):
        for lead in self:
            if lead.cmr_altura_libre and lead.cmr_config_equipo:
                base = lead.cmr_altura_libre - float(lead.cmr_config_equipo)
                lead.cmr_alto_eql = base - (lead.cmr_espesor_losa or 0.0)
                lead.cmr_alto_cap = base + (lead.cmr_espesor_losa or 0.0)
            else:
                lead.cmr_alto_eql = lead.cmr_alto_cap = 0.0

    @api.depends(
        "cmr_tipo_cotizacion_id.seccion_planos", "cmr_tipo_cotizacion_id.seccion_tecnica",
        "cmr_tipo_cotizacion_id.seccion_arquitectonica", "cmr_tipo_cotizacion_id.seccion_punto_fijo",
        "cmr_tipo_cotizacion_id.seccion_constructiva",
    )
    def _compute_cmr_secciones(self):
        for lead in self:
            tipo = lead.cmr_tipo_cotizacion_id
            # Sin tipo de cotización se muestran todas las secciones
            lead.cmr_ver_planos = not tipo or tipo.seccion_planos
            lead.cmr_ver_tecnica = not tipo or tipo.seccion_tecnica
            lead.cmr_ver_arquitectonica = not tipo or tipo.seccion_arquitectonica
            lead.cmr_ver_punto_fijo = not tipo or tipo.seccion_punto_fijo
            lead.cmr_ver_constructiva = not tipo or tipo.seccion_constructiva

    @api.depends(
        "type", "stage_id", "team_id", "cmr_tipo_cotizacion_id",
        "cmr_documento_ids.estado", "cmr_documento_ids.tipo_documento_id",
    )
    def _compute_cmr_pendientes(self):
        for lead in self:
            siguiente = lead._cmr_siguiente_etapa()
            lead.cmr_siguiente_etapa_id = siguiente
            pendientes = lead._cmr_requisitos_pendientes(siguiente) if siguiente else []
            lead.cmr_pendientes = "\n".join(f"• {p}" for p in pendientes) or False
            lead.cmr_pendientes_titulo = f"Para pasar a {siguiente.name} falta:" if pendientes else False

    # Sin dependencias a propósito: el candado de la vista refleja la etapa guardada. Si
    # dependiera de stage_id, al pasar a Volumetría desde la barra de etapas los campos se
    # volverían de solo lectura antes de guardar y se perderían los cambios sin guardar.
    def _compute_cmr_ficha_congelada(self):
        for lead in self:
            lead.cmr_ficha_congelada = lead._cmr_congela_en(lead.stage_id)

    def _cmr_congela_en(self, etapa, solo_etapa=False):
        """True si `etapa` es una etapa que congela o va después de una que congela.

        Con `solo_etapa` no se revisa el tipo del registro.
        """
        if not etapa or (not solo_etapa and any(lead.type != "opportunity" for lead in self)):
            return False
        inicio = self.env["crm.stage"].sudo().search([("cmr_congela_ficha", "=", True)])
        if not inicio:
            return False
        return orden_etapa(etapa) >= min(orden_etapa(s) for s in inicio)

    def _cmr_campos_congelados_modificados(self, vals):
        """Campos de la ficha que `vals` cambia realmente en este registro."""
        self.ensure_one()
        cambiados = []
        for nombre in CAMPOS_FICHA_CONGELABLE.intersection(vals):
            campo = self._fields[nombre]
            nuevo = campo.convert_to_record(campo.convert_to_cache(vals[nombre], self), self)
            if nuevo != self[nombre]:
                cambiados.append(campo.string)
        return cambiados

    def _cmr_validar_ficha_congelada(self, vals):
        if self.env.context.get(CTX_EDITAR_CONGELADA) or not CAMPOS_FICHA_CONGELABLE.intersection(vals):
            return
        etapa_nueva = self.env["crm.stage"].browse(vals["stage_id"]) if vals.get("stage_id") else None
        for lead in self:
            # Solo se bloquea si la ficha ya estaba congelada y sigue congelada después del cambio:
            # se puede corregir y enviar a Volumetría en un mismo guardado, o regresar y corregir.
            if not lead._cmr_congela_en(lead.stage_id):
                continue
            tipo = vals.get("type", lead.type)
            if tipo != "opportunity" or not lead._cmr_congela_en(etapa_nueva or lead.stage_id, solo_etapa=True):
                continue
            cambiados = lead._cmr_campos_congelados_modificados(vals)
            if cambiados:
                raise UserError(
                    self.env._(
                        "La ficha ESP-TEC de '%(op)s' está congelada en la etapa %(etapa)s.\n\n"
                        "No se puede cambiar: %(campos)s.\n\n"
                        "Para corregir la especificación, regresa la oportunidad a Revisión y Specs, "
                        "corrígela y vuelve a enviarla. El regreso queda registrado.",
                        op=lead.name,
                        etapa=(etapa_nueva or lead.stage_id).name,
                        campos=", ".join(sorted(cambiados)),
                    )
                )

    def _cmr_registrar_congelamiento(self, congeladas_antes):
        """Registra la entrada a una etapa congelada y cada regreso a una etapa anterior."""
        ahora = fields.Datetime.now()
        ctx = dict(self.env.context, cmr_skip_tag_sync=True, tracking_disable=True)
        for lead in self:
            antes = congeladas_antes.get(lead.id, False)
            ahora_congelada = lead.cmr_ficha_congelada
            if ahora_congelada and not antes:
                lead.with_context(ctx).write({"cmr_congelada_el": ahora, "cmr_congelada_por_id": self.env.uid})
                lead.message_post(
                    body=self.env._("Ficha ESP-TEC congelada al entrar a %(etapa)s.", etapa=lead.stage_id.name),
                    subtype_xmlid="mail.mt_note",
                )
            elif antes and not ahora_congelada and lead.type == "opportunity":
                regresos = lead.cmr_regresos_revision + 1
                lead.with_context(ctx).write({"cmr_regresos_revision": regresos})
                lead.message_post(
                    body=self.env._(
                        "Especificación regresada a %(etapa)s para corrección (regreso n.º %(n)s). "
                        "La ficha ESP-TEC vuelve a ser editable.",
                        etapa=lead.stage_id.name,
                        n=regresos,
                    ),
                    subtype_xmlid="mail.mt_note",
                )

    # ------------------------------------------------------------------
    # Documentos
    # ------------------------------------------------------------------
    @api.model
    def _cmr_documentos_por_defecto(self):
        tipos = self.env["cmr.tipo.documento"].search([("crear_por_defecto", "=", True)])
        return [Command.create({"tipo_documento_id": t.id, "sequence": t.sequence}) for t in tipos]

    # ------------------------------------------------------------------
    # Requisitos de avance
    # ------------------------------------------------------------------
    def _cmr_etapas_visibles(self):
        self.ensure_one()
        return self.env["crm.stage"].search(
            ["|", ("team_ids", "=", False), ("team_ids", "in", self.team_id.ids)]
        ).sorted(orden_etapa)

    def _cmr_siguiente_etapa(self):
        self.ensure_one()
        if self.type != "opportunity" or not self.stage_id or not self.active:
            return self.env["crm.stage"]
        actual = orden_etapa(self.stage_id)
        posteriores = self._cmr_etapas_visibles().filtered(lambda s: orden_etapa(s) > actual)
        return posteriores[:1]

    def _cmr_requisitos_aplicables(self, etapa):
        """Requisitos exigibles al entrar a `etapa`: los de esa etapa y los de etapas anteriores."""
        self.ensure_one()
        if not etapa:
            return self.env["cmr.requisito.etapa"]
        limite = orden_etapa(etapa)
        requisitos = self.env["cmr.requisito.etapa"].sudo().search([])
        return requisitos.filtered(lambda r: orden_etapa(r.etapa_id) <= limite and r._aplica_a(self))

    def _cmr_requisitos_pendientes(self, etapa):
        self.ensure_one()
        pendientes = []
        for req in self._cmr_requisitos_aplicables(etapa):
            texto = req._pendiente(self)
            if texto and texto not in pendientes:
                pendientes.append(texto)
        return pendientes

    @api.constrains("stage_id")
    def _check_cmr_requisitos_etapa(self):
        if self.env.context.get("cmr_omitir_requisitos"):
            return
        for lead in self:
            if lead.type != "opportunity" or not lead.stage_id:
                continue
            pendientes = lead._cmr_requisitos_pendientes(lead.stage_id)
            if pendientes:
                raise UserError(
                    self.env._(
                        "'%(op)s' no puede pasar a la etapa %(etapa)s.\n\n"
                        "Falta:\n- %(faltantes)s\n\n"
                        "Complétalo en la pestaña Especificaciones Técnicas. Si un documento no "
                        "se necesita en este caso, márcalo como «No aplica».",
                        op=lead.name,
                        etapa=lead.stage_id.name,
                        faltantes="\n- ".join(pendientes),
                    )
                )

    # ------------------------------------------------------------------
    # Etiqueta "Falta documentación": pendientes para la siguiente etapa
    # ------------------------------------------------------------------
    def _cmr_sync_tag_documentacion(self):
        tag = self.env.ref("cmr_crm.tag_falta_documentacion", raise_if_not_found=False)
        if not tag:
            return
        poner, quitar = self.browse(), self.browse()
        for lead in self.exists():
            siguiente = lead._cmr_siguiente_etapa()
            con_pendientes = bool(siguiente and lead._cmr_requisitos_pendientes(siguiente))
            if con_pendientes and tag not in lead.tag_ids:
                poner |= lead
            elif not con_pendientes and tag in lead.tag_ids:
                quitar |= lead
        ctx = dict(self.env.context, cmr_skip_tag_sync=True, tracking_disable=True)
        if poner:
            poner.with_context(ctx).write({"tag_ids": [Command.link(tag.id)]})
        if quitar:
            quitar.with_context(ctx).write({"tag_ids": [Command.unlink(tag.id)]})

    @api.model
    def _cmr_campos_requisitos(self):
        campos = self.env["cmr.requisito.etapa"].sudo().search([("tipo_requisito", "=", "campo")]).campo_id
        return CAMPOS_REQUISITOS_BASE | set(campos.mapped("name"))

    # ------------------------------------------------------------------
    # Plan de actividades al entrar a una etapa
    # ------------------------------------------------------------------
    def _cmr_lanzar_plan_etapa(self):
        for lead in self:
            plan = lead.stage_id.cmr_plan_id
            if lead.type != "opportunity" or not plan or not plan.template_ids:
                continue
            try:
                with self.env.cr.savepoint():
                    asistente = self.env["mail.activity.schedule"].with_context(
                        active_model="crm.lead", active_ids=lead.ids,
                    ).create({
                        "res_model": "crm.lead",
                        "res_ids": str(lead.ids),
                        "plan_id": plan.id,
                        "plan_on_demand_user_id": (lead.user_id or self.env.user).id,
                    })
                    asistente.action_schedule_plan()
            except Exception as error:  # noqa: BLE001 - un plan mal configurado no debe frenar la venta
                _logger.warning("No se pudo lanzar el plan %s en %s: %s", plan.name, lead.display_name, error)
                lead.message_post(
                    body=self.env._("No se pudo programar el plan «%(plan)s»: %(error)s", plan=plan.name, error=error),
                    subtype_xmlid="mail.mt_note",
                )

    # ------------------------------------------------------------------
    # ORM
    # ------------------------------------------------------------------
    @api.model_create_multi
    def create(self, vals_list):
        leads = super(CrmLead, self.with_context(cmr_skip_tag_sync=True)).create(vals_list)
        leads = leads.with_env(self.env)
        oportunidades = leads.filtered(lambda l: l.type == "opportunity")
        if not self.env.context.get("cmr_skip_tag_sync"):
            oportunidades._cmr_sync_tag_documentacion()
        oportunidades._cmr_lanzar_plan_etapa()
        oportunidades.filtered("cmr_ficha_congelada")._cmr_registrar_congelamiento({})
        return leads

    def write(self, vals):
        self._cmr_validar_ficha_congelada(vals)
        cambia_etapa = "stage_id" in vals or "type" in vals
        etapas_previas = {lead.id: lead.stage_id.id for lead in self} if "stage_id" in vals else {}
        congeladas_antes = {lead.id: lead.cmr_ficha_congelada for lead in self} if cambia_etapa else {}
        if self.env.context.get("cmr_skip_tag_sync"):
            return super().write(vals)
        res = super(CrmLead, self.with_context(cmr_skip_tag_sync=True)).write(vals)
        if set(vals) & self._cmr_campos_requisitos():
            self.filtered(lambda l: l.type == "opportunity")._cmr_sync_tag_documentacion()
        if etapas_previas:
            self.filtered(lambda l: l.stage_id.id != etapas_previas.get(l.id))._cmr_lanzar_plan_etapa()
        if cambia_etapa:
            self.invalidate_recordset(["cmr_ficha_congelada"])
            self._cmr_registrar_congelamiento(congeladas_antes)
        return res

    def _merge_opportunity(self, user_id=False, team_id=False, auto_unlink=True, max_length=5):
        """Fusionar oportunidades copia datos a la principal aunque su ficha esté congelada."""
        return super(CrmLead, self.with_context(**{CTX_EDITAR_CONGELADA: True}))._merge_opportunity(
            user_id=user_id, team_id=team_id, auto_unlink=auto_unlink, max_length=max_length,
        )

    def _prepare_opportunity_quotation_context(self):
        """La cotización nace con la plantilla del tipo de cotización de la oportunidad."""
        context = super()._prepare_opportunity_quotation_context()
        plantilla = self.cmr_tipo_cotizacion_id.plantilla_id
        if plantilla:
            context["default_sale_order_template_id"] = plantilla.id
        return context

    def _convert_opportunity_data(self, customer, team_id=False):
        data = super()._convert_opportunity_data(customer, team_id=team_id)
        if not self.cmr_documento_ids:
            data["cmr_documento_ids"] = self._cmr_documentos_por_defecto()
        return data
