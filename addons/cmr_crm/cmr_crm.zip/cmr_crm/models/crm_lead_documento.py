from markupsafe import Markup

from odoo import api, fields, models

ESTADOS_DOCUMENTO = [
    ("faltante", "Faltante"),
    ("recibido", "Recibido · revisión pendiente"),
    ("revisado", "Revisado"),
    ("na", "No aplica"),
]


class CrmLeadDocumento(models.Model):
    _name = "crm.lead.documento"
    _description = "Documento / plano de la oportunidad"
    _order = "sequence, id"

    lead_id = fields.Many2one("crm.lead", string="Oportunidad", required=True, ondelete="cascade", index=True)
    tipo_documento_id = fields.Many2one("cmr.tipo.documento", string="Documento", required=True, ondelete="restrict")
    sequence = fields.Integer(default=10)
    estado = fields.Selection(ESTADOS_DOCUMENTO, string="Estado", required=True, default="faltante")
    enlace = fields.Char(string="Enlace", help="Enlace al archivo vigente (SharePoint u otro repositorio).")
    version = fields.Char(string="Versión")
    fecha_recepcion = fields.Date(string="Recibido el")
    revisado_por_id = fields.Many2one("res.users", string="Revisado por", readonly=True)
    fecha_revision = fields.Date(string="Revisado el", readonly=True)
    notas = fields.Char(string="Notas")

    _unico_por_oportunidad = models.Constraint(
        "UNIQUE(lead_id, tipo_documento_id)",
        "Cada documento solo puede aparecer una vez en la oportunidad.",
    )

    @api.onchange("tipo_documento_id")
    def _onchange_tipo_documento_id(self):
        if self.tipo_documento_id:
            self.sequence = self.tipo_documento_id.sequence

    def _valores_por_estado(self, estado):
        hoy = fields.Date.context_today(self)
        vals = {}
        if estado in ("recibido", "revisado") and not self.fecha_recepcion:
            vals["fecha_recepcion"] = hoy
        if estado == "revisado":
            vals.update(revisado_por_id=self.env.uid, fecha_revision=hoy)
        elif self.revisado_por_id or self.fecha_revision:
            vals.update(revisado_por_id=False, fecha_revision=False)
        return vals

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if "sequence" not in vals and vals.get("tipo_documento_id"):
                vals["sequence"] = self.env["cmr.tipo.documento"].browse(vals["tipo_documento_id"]).sequence
            estado = vals.get("estado", "faltante")
            if estado in ("recibido", "revisado") and not vals.get("fecha_recepcion"):
                vals["fecha_recepcion"] = fields.Date.context_today(self)
            if estado == "revisado":
                vals.setdefault("revisado_por_id", self.env.uid)
                vals.setdefault("fecha_revision", fields.Date.context_today(self))
        docs = super().create(vals_list)
        if not self.env.context.get("cmr_skip_tag_sync"):
            docs.lead_id._cmr_sync_tag_documentacion()
        return docs

    def write(self, vals):
        if "estado" not in vals:
            return super().write(vals)
        anteriores = {doc.id: doc.estado for doc in self}
        etiquetas = dict(ESTADOS_DOCUMENTO)
        res = True
        for doc in self:
            res &= super(CrmLeadDocumento, doc).write({**doc._valores_por_estado(vals["estado"]), **vals})
        for doc in self:
            if anteriores[doc.id] != doc.estado:
                doc.lead_id.message_post(
                    body=Markup("<b>%s</b>: %s → %s")
                    % (doc.tipo_documento_id.name, etiquetas[anteriores[doc.id]], etiquetas[doc.estado]),
                    subtype_xmlid="mail.mt_note",
                )
        if not self.env.context.get("cmr_skip_tag_sync"):
            self.lead_id._cmr_sync_tag_documentacion()
        return res

    def unlink(self):
        leads = self.lead_id
        res = super().unlink()
        if not self.env.context.get("cmr_skip_tag_sync"):
            leads.exists()._cmr_sync_tag_documentacion()
        return res
