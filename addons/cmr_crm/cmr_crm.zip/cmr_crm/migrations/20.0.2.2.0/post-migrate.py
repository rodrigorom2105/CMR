"""Migración 20.0.2.1.0 → 20.0.2.2.0 · CILI-08 congelamiento de la ficha ESP-TEC

Acuerdo de la reunión 3 (30/10/2026): la ficha se congela al entrar a Volumetría Preliminar.
- Marca la etapa Volumetría Preliminar como etapa que congela. Las etapas se cargan con
  noupdate, así que el dato de la etapa no se actualiza solo.
- Las oportunidades que ya están en Volumetría o después quedan congeladas desde ahora.
  No se les pone fecha de congelamiento porque no se sabe cuándo entraron.
"""
import logging

from odoo import SUPERUSER_ID, api

_logger = logging.getLogger(__name__)


def migrate(cr, version):
    if not version:
        return
    env = api.Environment(cr, SUPERUSER_ID, {"active_test": False})
    Stage = env["crm.stage"]
    if Stage.search_count([("cmr_congela_ficha", "=", True)]):
        _logger.info("cmr_crm: ya hay una etapa que congela la ficha; no se cambia nada")
        return
    etapa = env.ref("cmr_crm.stage_volumetria", raise_if_not_found=False)
    if not etapa:
        etapa = Stage.search([("name", "=ilike", "Volumetría Preliminar")], limit=1)
    if not etapa:
        _logger.warning("cmr_crm: no se encontró la etapa Volumetría Preliminar; márcala a mano en Etapas")
        return
    etapa.cmr_congela_ficha = True
    congeladas = env["crm.lead"].search([("type", "=", "opportunity")]).filtered("cmr_ficha_congelada")
    _logger.info(
        "cmr_crm: la etapa %s congela la ficha; %s oportunidades quedan congeladas",
        etapa.name, len(congeladas),
    )
