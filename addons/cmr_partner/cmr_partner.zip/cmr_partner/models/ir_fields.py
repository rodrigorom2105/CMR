import re
import unicodedata

from odoo import api, models

from .sat_catalogs import SAT_SELECTION_FIELDS


def _normalize(text):
    """Minúsculas, sin acentos, sin punto final y con espacios simples."""
    text = unicodedata.normalize('NFKD', str(text or ''))
    text = ''.join(c for c in text if not unicodedata.combining(c))
    text = re.sub(r'\s+', ' ', text).strip().rstrip('.').strip()
    return text.lower()


class IrFieldsConverter(models.AbstractModel):
    _inherit = 'ir.fields.converter'

    @api.model
    def _str_to_selection(self, model, field, value, savepoint):
        if field.model_name == 'res.partner' and field.name in SAT_SELECTION_FIELDS:
            wanted = _normalize(value)
            for key, label in field.selection:
                description = label.split(' - ', 1)[-1]
                if wanted in {_normalize(key), _normalize(label), _normalize(description)}:
                    return key, []
        return super()._str_to_selection(model, field, value, savepoint)

    @api.model
    def db_id_for(self, model, field, subfield, value, savepoint):
        # País y Estado: si no hay coincidencia exacta, buscar sin acentos ni
        # mayúsculas ("COSTA RICA" -> Costa Rica, "PANAMA" -> Panamá). Solo se
        # usa cuando la coincidencia es única.
        if (subfield is None and isinstance(value, str) and value.strip()
                and field.comodel_name in ('res.country', 'res.country.state')):
            Related = self.env[field.comodel_name]
            if not Related.name_search(name=value, operator='='):
                wanted = _normalize(value)
                candidates = Related.search([]).filtered(lambda r: _normalize(r.name) == wanted)
                if len(candidates) == 1:
                    value = candidates.name
        return super().db_id_for(model, field, subfield, value, savepoint)
