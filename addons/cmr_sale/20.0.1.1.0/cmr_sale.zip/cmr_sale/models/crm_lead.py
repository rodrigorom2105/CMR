from odoo import fields, models


class CrmLead(models.Model):
    _inherit = "crm.lead"

    cmr_proyecto_numero = fields.Char(
        string="Nº de proyecto", readonly=True, copy=False, index=True,
        help="Se asigna con la primera cotización de la oportunidad y se reinicia cada año.",
    )
    cmr_proyecto_anio = fields.Char(string="Año del proyecto", readonly=True, copy=False)

    def _cmr_asignar_proyecto(self, fecha):
        """Devuelve (número, año de 2 dígitos) del proyecto; lo asigna si aún no tiene."""
        self.ensure_one()
        # Bloquea la oportunidad para que dos cotizaciones simultáneas no tomen números distintos
        self.env.cr.execute("SELECT id FROM crm_lead WHERE id = %s FOR UPDATE", [self.id])
        self.invalidate_recordset(["cmr_proyecto_numero", "cmr_proyecto_anio"])
        if not self.cmr_proyecto_numero:
            numero, anio = self.env["sale.order"]._cmr_nuevo_proyecto(fecha)
            self.sudo().write({"cmr_proyecto_numero": numero, "cmr_proyecto_anio": anio})
        return self.cmr_proyecto_numero, self.cmr_proyecto_anio
