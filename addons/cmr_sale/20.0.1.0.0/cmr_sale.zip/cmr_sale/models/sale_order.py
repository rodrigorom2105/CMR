from odoo import api, fields, models

CODIGO_SECUENCIA = "cmr.proyecto"


class SaleOrder(models.Model):
    _inherit = "sale.order"

    cmr_proyecto_numero = fields.Char(string="Nº de proyecto", readonly=True, copy=False, index=True)
    cmr_proyecto_anio = fields.Char(string="Año del proyecto", readonly=True, copy=False)
    cmr_opcion = fields.Integer(string="Opción", readonly=True, copy=False)

    @api.model
    def _cmr_formato(self, numero, opcion, anio):
        """Formato de CMR: 283- 12-26 (proyecto, espacio, opción de 2 dígitos, año de 2 dígitos)."""
        return f"{numero}- {opcion:02d}-{anio}"

    @api.model
    def _cmr_nuevo_proyecto(self, fecha):
        numero = self.env["ir.sequence"].sudo().next_by_code(CODIGO_SECUENCIA, sequence_date=fecha)
        return numero, fecha.strftime("%y")

    @api.model
    def _cmr_fecha(self, vals):
        if vals.get("date_order"):
            return fields.Datetime.context_timestamp(self, fields.Datetime.to_datetime(vals["date_order"])).date()
        return fields.Date.context_today(self)

    @api.model_create_multi
    def create(self, vals_list):
        nuevo = self.env._("New")
        for vals in vals_list:
            if vals.get("name", nuevo) != nuevo:
                continue  # nombre dado a mano o por otro proceso
            fecha = self._cmr_fecha(vals)
            lead = self.env["crm.lead"].browse(vals.get("opportunity_id") or [])
            if lead:
                numero, anio = lead._cmr_asignar_proyecto(fecha)
                anteriores = self.with_context(active_test=False).search(
                    [("opportunity_id", "=", lead.id), ("cmr_opcion", ">", 0)],
                    order="cmr_opcion desc", limit=1,
                )
                opcion = (anteriores.cmr_opcion or 0) + 1
            else:
                # Cotización sin oportunidad: proyecto propio
                numero, anio = self._cmr_nuevo_proyecto(fecha)
                opcion = 1
            vals.update({
                "name": self._cmr_formato(numero, opcion, anio),
                "cmr_proyecto_numero": numero,
                "cmr_proyecto_anio": anio,
                "cmr_opcion": opcion,
            })
        return super().create(vals_list)
