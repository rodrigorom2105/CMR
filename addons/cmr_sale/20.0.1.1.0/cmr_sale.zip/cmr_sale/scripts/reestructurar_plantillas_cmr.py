# Reestructura las 5 plantillas de cotización de CMR para el formato FT-CTZ-01 (cmr_sale 20.0.1.1.0).
#
# Uso (en el servidor, desde la carpeta de Odoo):
#   docker compose exec -T odoo odoo shell -d cmr_db --no-http < reestructurar_plantillas_cmr.py 2>&1 | tail -80
#
# Qué hace en cada plantilla «CMR – …»:
#   1. Los títulos de equipo de aluminio («Molde – Planta baja», «Punto fijo – Primer nivel», «Pretil – Azotea»,
#      «Escalera», «Equipo existente – Planta alta», …) pasan a ser SUBSECCIONES: cada una saca su TOTAL MT2,
#      TOTAL ML y SUBTOTAL.
#   2. Se agregan las secciones que las agrupan: «Equipo de aluminio – <planta>» (o «Equipo de aluminio» si la
#      plantilla no se divide por planta). En Molde por niveles, «Andamiaje» y «Alineación» de cada planta van en
#      «Complementarios – <planta>».
#   3. Se ordena como el Excel de CMR: primero todo el equipo de aluminio, luego los complementarios por planta y
#      al final las secciones propias (Complementarios, Logística, Servicios, Flete y servicios, Accesorios…),
#      en su orden original. Dentro de cada bloque no cambia el orden de las líneas.
#   4. Marca el producto «Flete» como flete de la cotización CMR, para que salga en los totales del PDF.
#
# No toca cotizaciones ya creadas, productos (salvo la marca del paso 4) ni precios.
# Con APLICAR = False hace los cambios para probarlos y al final los deshace. Si hay un error, no guarda nada.
# Se puede correr varias veces: una plantilla que ya tiene subsecciones se deja igual.

import re

APLICAR = True

ALUMINIO = {
    "molde", "punto fijo", "escalera", "muro de patio", "pretil", "tinaquera",
    "equipo existente", "reborde de fachada",
}
COMPLEMENTO_POR_PLANTA = {"andamiaje", "alineación", "alineacion"}
PLANTAS_SUPERIORES = {"azotea"}  # se agrupan con la última planta anterior
SEPARADOR = re.compile(r"\s+[–—-]\s+")
GRUPO_ALUMINIO = "Equipo de aluminio"
GRUPO_COMPLEMENTO = "Complementarios"


def partir(titulo):
    partes = SEPARADOR.split((titulo or "").strip(), maxsplit=1)
    base = partes[0].strip()
    planta = partes[1].strip() if len(partes) > 1 else ""
    return base, planta


def bloques_de(lineas):
    """[(título, [líneas del bloque])] en el orden de la plantilla; las líneas antes de un título van con None."""
    bloques, actual = [], (None, [])
    for linea in lineas:
        if linea.display_type == "line_section":
            if actual[0] is not None or actual[1]:
                bloques.append(actual)
            actual = (linea, [])
        else:
            actual[1].append(linea)
    if actual[0] is not None or actual[1]:
        bloques.append(actual)
    return bloques


def plan_plantilla(plantilla):
    lineas = plantilla.sale_order_template_line_ids.sorted("sequence")
    if any(l.display_type == "line_subsection" for l in lineas):
        return None, "ya tiene subsecciones; sin cambios"
    bloques = bloques_de(lineas)

    # Plantas de los bloques de aluminio, en orden de aparición
    plantas, ultima = [], ""
    clasificados = []
    for titulo, contenido in bloques:
        if titulo is None:
            clasificados.append(("suelto", "", titulo, contenido))
            continue
        base, planta = partir(titulo.name)
        clave = base.lower()
        if clave in ALUMINIO:
            if planta.lower() in PLANTAS_SUPERIORES or not planta:
                planta = ultima
            elif planta not in plantas:
                plantas.append(planta)
            ultima = planta or ultima
            clasificados.append(("aluminio", planta, titulo, contenido))
        elif clave in COMPLEMENTO_POR_PLANTA and planta:
            clasificados.append(("complemento", planta, titulo, contenido))
        else:
            clasificados.append(("propio", "", titulo, contenido))

    por_planta = len(plantas) > 1

    def nombre_grupo(base, planta):
        return f"{base} – {planta}" if por_planta and planta else base

    salida = []  # [(acción, línea o nombre, display_type)]
    for item in [c for c in clasificados if c[0] == "suelto"]:
        salida.extend(("mantener", l, l.display_type) for l in item[3])
    for clase, base in (("aluminio", GRUPO_ALUMINIO), ("complemento", GRUPO_COMPLEMENTO)):
        grupos = {}
        orden = []
        for item in clasificados:
            if item[0] != clase:
                continue
            nombre = nombre_grupo(base, item[1])
            if nombre not in grupos:
                grupos[nombre] = []
                orden.append(nombre)
            grupos[nombre].append(item)
        for nombre in orden:
            salida.append(("nueva", nombre, "line_section"))
            for _clase, _planta, titulo, contenido in grupos[nombre]:
                salida.append(("subseccion", titulo, "line_subsection"))
                salida.extend(("mantener", l, l.display_type) for l in contenido)
    for item in clasificados:
        if item[0] == "propio":
            salida.append(("mantener", item[2], item[2].display_type))
            salida.extend(("mantener", l, l.display_type) for l in item[3])
    return salida, None


def aplicar(plantilla, salida):
    Linea = env["sale.order.template.line"]  # noqa: F821 - env lo da odoo shell
    secuencia = 10
    for accion, objeto, tipo in salida:
        if accion == "nueva":
            Linea.create({
                "sale_order_template_id": plantilla.id,
                "display_type": "line_section",
                "name": objeto,
                "sequence": secuencia,
            })
        elif accion == "subseccion":
            # Odoo no deja cambiar el tipo de una línea de plantilla: se crea la subsección
            # con el mismo título en la misma posición y se borra el título anterior.
            Linea.create({
                "sale_order_template_id": plantilla.id,
                "display_type": "line_subsection",
                "name": objeto.name,
                "sequence": secuencia,
            })
            objeto.unlink()
        else:
            if objeto.sequence != secuencia:
                objeto.write({"sequence": secuencia})
        secuencia += 10


cambios = errores = 0
try:
    plantillas = env["sale.order.template"].search([("name", "=ilike", "CMR%")], order="id")  # noqa: F821
    if not plantillas:
        print("== No se encontraron plantillas «CMR – …»")
    for plantilla in plantillas:
        print(f"\n## {plantilla.name}")
        salida, motivo = plan_plantilla(plantilla)
        if salida is None:
            print(f"   {motivo}")
            continue
        for accion, objeto, tipo in salida:
            if accion == "nueva":
                print(f"   + SECCIÓN NUEVA     {objeto}")
            elif accion == "subseccion":
                print(f"     sección → SUBSECCIÓN  {objeto.name}")
            elif tipo == "line_section":
                print(f"   = sección          {objeto.name}")
        # También en revisión se aplican los cambios (y luego se deshacen), para detectar errores
        aplicar(plantilla, salida)
        cambios += 1

    flete = env["product.template"].with_context(active_test=False).search([("name", "=ilike", "Flete")])  # noqa: F821
    for producto in flete:
        if not producto.cmr_es_flete:
            print(f"\n## Producto «{producto.name}» → se marca como flete de la cotización CMR")
            producto.cmr_es_flete = True
            cambios += 1
    if not flete:
        print("\n== Aviso: no hay un producto llamado exactamente «Flete»; márcalo a mano en su ficha")
except Exception as error:  # noqa: BLE001
    errores += 1
    print(f"ERROR: {error}")

if errores:
    env.cr.rollback()  # noqa: F821
    print(f"\n== Cambios: {cambios} | Errores: {errores}")
    print("== No se guardó nada.")
elif APLICAR:
    env.cr.commit()  # noqa: F821
    print(f"\n== Cambios: {cambios} | Errores: 0")
    print("== Guardado.")
else:
    env.cr.rollback()  # noqa: F821
    print(f"\n== Cambios: {cambios} | Errores: 0")
    print("== Modo revisión (APLICAR = False): no se guardó nada.")
