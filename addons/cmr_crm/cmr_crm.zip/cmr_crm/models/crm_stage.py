from odoo import fields, models


class CrmStage(models.Model):
    _inherit = "crm.stage"

    cmr_requisito_ids = fields.One2many(
        "cmr.requisito.etapa",
        "etapa_id",
        string="Requisitos para entrar",
        help="Documentos y datos que debe tener una oportunidad para entrar a esta etapa "
        "o a cualquier etapa posterior.",
    )
    cmr_plan_id = fields.Many2one(
        "mail.activity.plan",
        string="Plan de actividades al entrar",
        domain="[('res_model', '=', 'crm.lead')]",
        help="Al entrar una oportunidad a esta etapa se programan las actividades del plan "
        "(responsable y vencimiento según la plantilla). Las actividades «a definir» "
        "se asignan al vendedor de la oportunidad.",
    )
