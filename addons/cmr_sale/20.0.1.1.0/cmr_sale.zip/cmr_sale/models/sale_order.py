import re

from odoo import api, fields, models
from odoo.exceptions import ValidationError
from odoo.tools import float_compare, float_is_zero, is_html_empty
from odoo.tools.misc import formatLang

try:
    from num2words import num2words
except ImportError:  # pragma: no cover - num2words es dependencia de Odoo
    num2words = None

CODIGO_SECUENCIA = "cmr.proyecto"

# Unidades como las escribe CMR en el formato FT-CTZ-01
UNIDADES_CMR = {
    "uom.product_uom_square_meter": "MT2",
    "uom.product_uom_meter": "MTL",
    "uom.product_uom_unit": "PZ",
}
MONEDA_EN_LETRA = {"USD": "DÓLARES AMERICANOS", "MXN": "PESOS MEXICANOS M.N."}
# Separador entre bloque y planta en los títulos: «Equipo de aluminio – Planta baja»
SEPARADOR_TITULO = re.compile(r"\s+[–—-]\s+")


class SaleOrder(models.Model):
    _inherit = "sale.order"

    cmr_proyecto_numero = fields.Char(string="Nº de proyecto", readonly=True, copy=False, index=True)
    cmr_proyecto_anio = fields.Char(string="Año del proyecto", readonly=True, copy=False)
    cmr_opcion = fields.Integer(string="Opción", readonly=True, copy=False)

    # ------------------------------------------------------------------
    # Formato FT-CTZ-01: encabezado
    # ------------------------------------------------------------------
    cmr_producto_cotizado = fields.Char(string="Producto cotizado")
    cmr_referencia = fields.Text(string="Referencia", help="Descripción de la opción que se cotiza.")
    cmr_pais_ciudad = fields.Char(
        string="País / ciudad", compute="_compute_cmr_datos_oportunidad", store=True, readonly=False,
        precompute=True, help="Ubicación de la obra. Se toma de la oportunidad y se puede cambiar.",
    )
    cmr_contacto = fields.Char(
        string="Contacto", compute="_compute_cmr_datos_oportunidad", store=True, readonly=False, precompute=True,
    )
    cmr_contacto_medio = fields.Char(
        string="Correo o teléfono del contacto", compute="_compute_cmr_datos_oportunidad", store=True,
        readonly=False, precompute=True,
    )

    # ------------------------------------------------------------------
    # Formato FT-CTZ-01: condiciones comerciales
    # ------------------------------------------------------------------
    cmr_garantia = fields.Char(string="Garantía", default="APLICAN SEGÚN CONTRATO")
    cmr_observaciones = fields.Text(string="Observaciones")
    cmr_tiempo_transito = fields.Char(string="Tiempo de tránsito")
    cmr_hito_ids = fields.One2many("cmr.sale.hito", "order_id", string="Forma de pago", copy=True)
    cmr_entrega_ids = fields.One2many("cmr.sale.entrega", "order_id", string="Tiempo de entrega", copy=True)
    cmr_memoria_ids = fields.One2many("cmr.sale.memoria", "order_id", string="Memoria gráfica", copy=True)
    cmr_mostrar_total_mxn = fields.Boolean(
        string="Mostrar total en MXN",
        help="Agrega al PDF el renglón TOTAL MXN, con el tipo de cambio de la fecha de la cotización.",
    )
    cmr_hitos_porcentaje = fields.Float(
        string="Suma de hitos (%)", compute="_compute_cmr_hitos_porcentaje", digits=(16, 2),
    )

    def _cmr_valores_oportunidad(self):
        """País/ciudad de la obra y contacto, tomados de la oportunidad y del cliente."""
        self.ensure_one()
        lead = self.opportunity_id
        partner = self.partner_id
        pais = lead.country_id or partner.country_id
        ciudad = (lead.cmr_obra_ciudad or lead.city or partner.city or "") if lead else (partner.city or "")
        partes = [p for p in (pais.name if pais else "", ciudad) if p]

        # Contacto: nombre del contacto de la oportunidad; si no hay, la persona de la cotización o de la
        # oportunidad; si el cliente es una empresa, su primer contacto (persona) registrado.
        persona = self.env["res.partner"]
        for candidato in (partner, lead.partner_id):
            if candidato and not candidato.is_company:
                persona = candidato
                break
        if not persona:
            empresa = (partner or lead.partner_id).commercial_partner_id
            if empresa:
                persona = empresa.child_ids.filtered(
                    lambda c: not c.is_company and c.type == "contact" and c.active
                ).sorted("id")[:1]
        nombre = (lead.contact_name if lead else False) or persona.name
        medio = (
            (lead.email_from or lead.phone) if lead else False
        ) or persona.email or persona.phone or partner.email or partner.phone
        return {
            "cmr_pais_ciudad": " / ".join(partes).upper() or False,
            "cmr_contacto": nombre or False,
            "cmr_contacto_medio": medio or False,
        }

    @api.depends("opportunity_id", "partner_id")
    def _compute_cmr_datos_oportunidad(self):
        for order in self:
            order.update(order._cmr_valores_oportunidad())

    def action_cmr_llenar_desde_oportunidad(self):
        """Vuelve a llenar país/ciudad y contacto (por ejemplo, después de completar la oportunidad)."""
        for order in self:
            order.write(order._cmr_valores_oportunidad())
        return True

    @api.depends("cmr_hito_ids.porcentaje", "cmr_hito_ids.alternativa")
    def _compute_cmr_hitos_porcentaje(self):
        for order in self:
            order.cmr_hitos_porcentaje = sum(order.cmr_hito_ids.filtered(lambda h: not h.alternativa).mapped("porcentaje"))

    @api.constrains("cmr_hito_ids")
    def _check_cmr_hitos(self):
        for order in self:
            hitos = order.cmr_hito_ids.filtered(lambda h: not h.alternativa)
            if hitos and float_compare(sum(hitos.mapped("porcentaje")), 100.0, precision_digits=2):
                raise ValidationError(self.env._(
                    "Los hitos de pago de %(cot)s suman %(pct)s %%; deben sumar 100 %%. "
                    "Las formas de pago completas, como «100 %% leasing» o «al contado», "
                    "márcalas como alternativa.",
                    cot=order.name, pct=f"{sum(hitos.mapped('porcentaje')):g}",
                ))

    @api.model
    def _cmr_formato(self, numero, opcion, anio):
        """Formato de CMR: 283- 12-26 (proyecto, espacio, opción de 2 dígitos, año de 2 dígitos)."""
        return f"{numero}- {opcion:02d}-{anio}"

    @api.model
    def _cmr_nuevo_proyecto(self, fecha):
        numero = self.env["ir.sequence"].sudo().next_by_code(CODIGO_SECUENCIA, sequence_date=fecha)
        return numero, fecha.strftime("%y")

    @api.model
    def _cmr_fecha(self, vals):
        if vals.get("date_order"):
            return fields.Datetime.context_timestamp(self, fields.Datetime.to_datetime(vals["date_order"])).date()
        return fields.Date.context_today(self)

    @api.model_create_multi
    def create(self, vals_list):
        nuevo = self.env._("New")
        for vals in vals_list:
            if vals.get("name", nuevo) != nuevo:
                continue  # nombre dado a mano o por otro proceso
            fecha = self._cmr_fecha(vals)
            lead = self.env["crm.lead"].browse(vals.get("opportunity_id") or [])
            if lead:
                numero, anio = lead._cmr_asignar_proyecto(fecha)
                anteriores = self.with_context(active_test=False).search(
                    [("opportunity_id", "=", lead.id), ("cmr_opcion", ">", 0)],
                    order="cmr_opcion desc", limit=1,
                )
                opcion = (anteriores.cmr_opcion or 0) + 1
            else:
                # Cotización sin oportunidad: proyecto propio
                numero, anio = self._cmr_nuevo_proyecto(fecha)
                opcion = 1
            vals.update({
                "name": self._cmr_formato(numero, opcion, anio),
                "cmr_proyecto_numero": numero,
                "cmr_proyecto_anio": anio,
                "cmr_opcion": opcion,
            })
        return super().create(vals_list)

    # ------------------------------------------------------------------
    # Datos para el PDF FT-CTZ-01
    # ------------------------------------------------------------------
    def _cmr_es_descuento(self, line):
        producto = self.company_id.sale_discount_product_id
        return bool(producto) and line.product_id == producto

    def _cmr_es_flete(self, line):
        return bool(line.product_id.product_tmpl_id.cmr_es_flete)

    def _cmr_unidad(self, line):
        uom = line.product_uom_id
        for xmlid, etiqueta in UNIDADES_CMR.items():
            ref = self.env.ref(xmlid, raise_if_not_found=False)
            if ref and uom == ref:
                return etiqueta
        return (uom.name or "").upper()

    def _cmr_fmt_monto(self, monto, moneda=None):
        moneda = moneda or self.currency_id
        return f"{moneda.name} {formatLang(self.env, monto, currency_obj=moneda)}"

    def _cmr_fmt_cantidad(self, cantidad):
        if float_is_zero(cantidad - round(cantidad), precision_digits=4):
            return formatLang(self.env, cantidad, digits=0)
        return formatLang(self.env, cantidad, digits=2)

    def _cmr_importe_letra(self, monto):
        """«TRESCIENTOS … CON 63/100 DÓLARES AMERICANOS», como en el formato de CMR."""
        if num2words is None:
            return ""
        entero = int(round(monto, 2))
        centavos = int(round((round(monto, 2) - entero) * 100))
        if centavos < 0:
            entero, centavos = entero - 1, centavos + 100
        texto = num2words(entero, lang="es")
        # «veintiuno dólares» → «veintiún dólares»; «uno» → «un»
        texto = re.sub(r"veintiuno$", "veintiún", texto)
        texto = re.sub(r"(^|\s)uno$", r"\1un", texto)
        moneda = MONEDA_EN_LETRA.get(self.currency_id.name) or (self.currency_id.currency_unit_label or self.currency_id.name)
        return f"{texto} con {centavos:02d}/100 {moneda}".upper()

    @api.model
    def _cmr_prefijo(self, titulo):
        return SEPARADOR_TITULO.split((titulo or "").strip(), maxsplit=1)[0].strip()

    def _cmr_acumular(self, destino, line):
        unidad = self._cmr_unidad(line)
        if unidad == "MT2":
            destino["m2"] += line.product_uom_qty
        elif unidad == "MTL":
            destino["ml"] += line.product_uom_qty
        destino["subtotal"] += line.price_subtotal

    def _cmr_reporte(self):
        """Estructura de la cotización para el PDF FT-CTZ-01.

        Secciones de Odoo = bloques con «VALOR TOTAL …»; subsecciones = tablas
        «COTIZACIÓN CIMBRA PARA …» con TOTAL MT2, TOTAL ML y SUBTOTAL. El flete y el
        descuento se sacan de las secciones y se muestran en los totales.
        """
        self.ensure_one()
        vacio = lambda: {"m2": 0.0, "ml": 0.0, "subtotal": 0.0}  # noqa: E731
        sueltas = {"items": [], **vacio()}
        secciones, seccion, sub = [], None, None
        subtotal = descuento = flete = 0.0
        for line in self.order_line.sorted("sequence"):
            if line.is_downpayment:
                continue
            if line.display_type == "line_section":
                seccion = {"linea": line, "items": [], "subs": 0, **vacio()}
                secciones.append(seccion)
                sub = None
                continue
            if line.display_type == "line_subsection":
                sub = {"linea": line, "items": [], **vacio()}
                if seccion is None:
                    seccion = {"linea": None, "items": [], "subs": 0, **vacio()}
                    secciones.append(seccion)
                seccion["items"].append(("sub", sub))
                seccion["subs"] += 1
                continue
            if not line.display_type:
                if self._cmr_es_descuento(line):
                    descuento -= line.price_subtotal
                    continue
                if self._cmr_es_flete(line):
                    flete += line.price_subtotal
                    continue
                subtotal += line.price_subtotal
            tipo = "nota" if line.display_type == "line_note" else "linea"
            destino = sub or seccion or sueltas
            destino["items"].append((tipo, line))
            if tipo == "linea":
                self._cmr_acumular(destino, line)
                if sub is not None:
                    self._cmr_acumular(seccion, line)

        # Quita secciones que quedaron vacías (por ejemplo, «Flete» sin otras líneas)
        secciones = [s for s in secciones if s["items"]]

        # «VALOR TOTAL EQUIPO DE ALUMINIO» cuando hay varios bloques con el mismo nombre base
        bloques = []
        por_prefijo = {}
        for s in secciones:
            if s["linea"]:
                por_prefijo.setdefault(self._cmr_prefijo(s["linea"].name).upper(), []).append(s)
        ultimos = {id(grupo[-1]): (prefijo, grupo) for prefijo, grupo in por_prefijo.items() if len(grupo) > 1}
        for s in secciones:
            bloques.append(("seccion", s))
            if id(s) in ultimos:
                prefijo, grupo = ultimos[id(s)]
                bloques.append(("gran_total", {
                    "nombre": prefijo,
                    "m2": sum(g["m2"] for g in grupo),
                    "ml": sum(g["ml"] for g in grupo),
                    "subtotal": sum(g["subtotal"] for g in grupo),
                }))

        sub1 = subtotal - descuento
        vigencia = ""
        if self.validity_date and self.date_order:
            dias = (self.validity_date - fields.Date.context_today(self, self.date_order)).days
            vigencia = f"{dias} DÍAS" if dias > 0 else ""
        total_mxn = False
        mxn = self.env.ref("base.MXN", raise_if_not_found=False)
        if self.cmr_mostrar_total_mxn and mxn and self.currency_id != mxn:
            total_mxn = self.currency_id._convert(
                self.amount_total, mxn, self.company_id, fields.Date.context_today(self, self.date_order),
            )
        incoterm = " ".join(p for p in (self.incoterm.code if self.incoterm else "", self.incoterm_location or "") if p)
        return {
            "sueltas": sueltas,
            "bloques": bloques,
            "subtotal": subtotal,
            "descuento": descuento,
            "descuento_pct": (descuento / subtotal * 100.0) if subtotal and descuento else 0.0,
            "sub1": sub1,
            "flete": flete,
            "sub2": self.amount_untaxed,
            "iva": self.amount_tax,
            "total": self.amount_total,
            "total_mxn": total_mxn,
            "mxn": mxn,
            "letra": self._cmr_importe_letra(self.amount_total),
            "vigencia": vigencia,
            "incoterm": incoterm.upper(),
            "hitos": self.cmr_hito_ids,
            "entregas": self.cmr_entrega_ids,
            "memoria": self.cmr_memoria_ids,
            "condiciones": not is_html_empty(self.note),
            "logo_cliente": self.partner_id.commercial_partner_id.image_1920,
        }
