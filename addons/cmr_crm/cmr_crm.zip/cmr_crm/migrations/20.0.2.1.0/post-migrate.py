"""Migración 20.0.2.0.0 → 20.0.2.1.0

Tipos de cotización alineados con las 5 plantillas de cotización de CMR (29/10/2026):
- Renombra los 4 tipos anteriores solo si conservan el nombre original (no pisa cambios hechos a mano).
- El tipo nuevo "Molde vivienda PB + planta alta" lo crea la carga de datos.
- Agrega el tipo nuevo a los requisitos iniciales que aplicaban a "Molde completo".
"""
import logging

from odoo import SUPERUSER_ID, api

_logger = logging.getLogger(__name__)

RENOMBRAR = {
    "cmr_crm.tipo_cot_molde_completo": ("Molde completo", "Molde por niveles", 1),
    "cmr_crm.tipo_cot_adaptacion": ("Adaptación", "Adaptación / repotenciación", 3),
    "cmr_crm.tipo_cot_listado": ("Listado", "Fabricación por listado / reparación", 4),
    "cmr_crm.tipo_cot_accesorios": ("Accesorios", "Venta de accesorios", 5),
}
REQUISITOS = [
    "cmr_crm.req_volumetria_plantas",
    "cmr_crm.req_volumetria_cortes",
    "cmr_crm.req_cotizacion_m2",
]


def migrate(cr, version):
    if not version:
        return
    env = api.Environment(cr, SUPERUSER_ID, {"active_test": False})
    for xmlid, (anterior, nuevo, secuencia) in RENOMBRAR.items():
        tipo = env.ref(xmlid, raise_if_not_found=False)
        if tipo and tipo.name == anterior:
            tipo.write({"name": nuevo, "sequence": secuencia})
            _logger.info("cmr_crm: tipo de cotización '%s' -> '%s'", anterior, nuevo)

    completo = env.ref("cmr_crm.tipo_cot_molde_completo", raise_if_not_found=False)
    vivienda = env.ref("cmr_crm.tipo_cot_molde_vivienda", raise_if_not_found=False)
    if not (completo and vivienda):
        return
    for xmlid in REQUISITOS:
        req = env.ref(xmlid, raise_if_not_found=False)
        if req and completo in req.tipo_cotizacion_ids and vivienda not in req.tipo_cotizacion_ids:
            req.tipo_cotizacion_ids = [(4, vivienda.id)]
            _logger.info("cmr_crm: '%s' ahora también aplica a %s", req.name, vivienda.name)
