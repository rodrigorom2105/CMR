{
    'name': 'CMR - Contactos con datos fiscales SAT',
    'summary': 'Régimen fiscal, uso de CFDI, forma y método de pago y domicilio fiscal '
               'desglosado en contactos, con importación directa del Excel de Factura Total.',
    'version': '20.0.1.1.0',
    'category': 'Sales/CRM',
    'author': 'Cili',
    'license': 'LGPL-3',
    'depends': ['contacts', 'account', 'base_import'],
    'data': [
        'data/account_payment_term_data.xml',
        'data/base_import_mapping_data.xml',
        'views/res_partner_views.xml',
    ],
    'installable': True,
    'application': False,
}
