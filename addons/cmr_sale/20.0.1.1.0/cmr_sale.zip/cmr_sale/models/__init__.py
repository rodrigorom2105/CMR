from . import cmr_cotizacion
from . import crm_lead
from . import product_template
from . import sale_order
from . import res_config_settings
